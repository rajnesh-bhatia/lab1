#include<iostream>  //including header files 
#include <time.h> 
#define MATRIXSIZE 2		//defining size

using namespace std;			//using standard namespace


class matrix {

	//making functions public
public:

	void strassen(int a[MATRIXSIZE][MATRIXSIZE], int b[MATRIXSIZE][MATRIXSIZE])
	{
		int c[MATRIXSIZE][MATRIXSIZE];
		int m1, m2, m3, m4, m5, m6, m7;

							//Making the 7 big numbers 
		m1 = (a[0][0] + a[1][1]) * (b[0][0] + b[1][1]);
		m2 = (a[1][0] + a[1][1]) * b[0][0];
		m3 = a[0][0] * (b[0][1] - b[1][1]);
		m4 = a[1][1] * (b[1][0] - b[0][0]);
		m5 = (a[0][0] + a[0][1]) * b[1][1];
		m6 = (a[1][0] - a[0][0]) * (b[0][0] + b[0][1]);
		m7 = (a[0][1] - a[1][1]) * (b[1][0] + b[1][1]);
	


							//Assigning values 
		c[0][0] = m1 + m4 - m5 + m7;
		c[0][1] = m3 + m5;
		c[1][0] = m2 + m4;
		c[1][1] = m1 - m2 + m3 + m6;
		

		for (int i = 0; i < MATRIXSIZE; i++)
		{
			for (int j = 0; j < MATRIXSIZE; j++)
			{
				cout << "\t" << c[i][j];
			}
			cout << "\n";
		}
		

	}

	void multiply(int a[MATRIXSIZE][MATRIXSIZE], int b[MATRIXSIZE][MATRIXSIZE])
	{       
		int c[MATRIXSIZE][MATRIXSIZE];
		int k, i, j;
		for (i = 0; i < MATRIXSIZE; i++)
		{
			for (j = 0; j < MATRIXSIZE; j++)
			{
				int add = 0;
				for (k = 0; k < MATRIXSIZE; k++)
				{
					add = add + a[i][k] * b[k][j];   //Adding the products 
				}
				c[i][j] = add;
			}
		}
				
		//Displaying the matrix
		for (int i = 0; i < MATRIXSIZE; i++)
		{
			for (int j = 0; j < MATRIXSIZE; j++)
			{
				cout << "\t" << c[i][j];
			}
			cout << "\n";
		}
		
	}
};

int main(){

	matrix obj;
	int a[MATRIXSIZE][MATRIXSIZE], b[MATRIXSIZE][MATRIXSIZE], c[MATRIXSIZE][MATRIXSIZE];
	//This will allow you to input the numbers individually to fill the array.

	srand(time(NULL));

	for (int i = 0; i < MATRIXSIZE; i++)
	{
		for (int j = 0; j < MATRIXSIZE; j++)
		{
			a[i][j] = rand() % 9 + 1;
			b[i][j] = rand() % 9 + 1;
		
		}
	}
	cout << "\n\nWith Ierative\n";
	obj.multiply(a ,b);
		


	cout << "\n\nWith Strassen\n";
	obj.strassen(a, b);

	return 0;
}